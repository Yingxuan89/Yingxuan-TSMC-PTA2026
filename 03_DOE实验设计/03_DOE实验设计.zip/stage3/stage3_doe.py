"""
第三阶段：DOE 实验设计与工艺窗口验证（模拟数据）

因子：A 栅长 CD、B 栅介质厚度、C 阈值调节注入剂量
设计：三因子面心中心复合设计（CCF），8 个角点 + 6 个轴点 + 6 个中心点 = 20 片，
      外加 3 片 Inline 监控片和 2 片备用片，共 25 片（一个完整批次）
响应：Vt、log10(漏电流)、良率

运行：python stage3_doe.py
输出：data/ 实验矩阵与模拟数据；figures/ 图表；results/ 统计结果
依赖：numpy, pandas, scipy, matplotlib
"""
import os, json, itertools
import numpy as np
import pandas as pd
from scipy import stats
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams["font.sans-serif"] = ["Noto Sans CJK SC", "PingFang SC", "Microsoft YaHei", "SimHei"]
plt.rcParams["axes.unicode_minus"] = False
plt.rcParams["figure.dpi"] = 150

OUT = os.path.dirname(os.path.abspath(__file__))
for sub in ("data", "figures", "results"):
    os.makedirs(os.path.join(OUT, sub), exist_ok=True)
rng = np.random.default_rng(2026)

# ---------- 1. 因子与水平（中心值取第一阶段 7nm 管控范围中心） ----------
FACTORS = {
    "A": dict(name="栅长 CD", field="critical_dimension", center=18.1, step=2.0, unit="nm"),
    "B": dict(name="栅介质厚度", field="oxide_thickness", center=50.0, step=4.0, unit="Å"),
    "C": dict(name="注入剂量", field="dose", center=1.00e15, step=0.05e15, unit="cm⁻²"),
}
def to_real(k, x): return FACTORS[k]["center"] + FACTORS[k]["step"] * x

# ---------- 2. 实验矩阵：面心中心复合设计 ----------
corner = list(itertools.product([-1, 1], repeat=3))
axial = [(-1, 0, 0), (1, 0, 0), (0, -1, 0), (0, 1, 0), (0, 0, -1), (0, 0, 1)]
center = [(0, 0, 0)] * 6
runs = [("角点", p) for p in corner] + [("轴点", p) for p in axial] + [("中心点", p) for p in center]
design = pd.DataFrame([dict(类型=t, A=a, B=b, C=c) for t, (a, b, c) in runs])
design.insert(0, "run", range(1, len(design) + 1))
# 随机分配到晶圆槽位 1–25（槽位 1、13、25 为监控片，24 为备用，另一片备用为 12）
slots = [s for s in range(1, 26) if s not in (1, 12, 13, 24, 25)]
design["wafer_slot"] = rng.permutation(slots)
for k in "ABC":
    design[FACTORS[k]["field"]] = to_real(k, design[k])

# ---------- 3. 模拟响应（模型与依据见报告 B.1） ----------
A, B, C = design.A.values, design.B.values, design.C.values
vt_true = (0.586 + 0.022 * A + 0.016 * B + 0.025 * C
           + 0.006 * A * C - 0.008 * A ** 2)
leak_true = (-3.50 - 0.25 * A - 0.30 * B - 0.20 * C
             + 0.10 * B ** 2 + 0.06 * A * B)
design["vth"] = vt_true + rng.normal(0, 0.012, len(design))
design["log_leakage"] = leak_true + rng.normal(0, 0.08, len(design))
def yield_model(vt, logleak, a, b):
    return (0.62 - 22 * (vt - 0.586) ** 2
            - 0.10 * np.maximum(0, logleak + 3.30)
            - 0.03 * a - 0.03 * b)
design["yield"] = np.clip(yield_model(design.vth, design.log_leakage, A, B) + rng.normal(0, 0.025, len(design)), 0, 1)
design["leakage_current"] = 10 ** design.log_leakage
design.to_csv(os.path.join(OUT, "data/doe_matrix_and_results.csv"), index=False, float_format="%.5g")

# ---------- 4. 二次响应面拟合（最小二乘 + t 检验） ----------
TERMS = ["A", "B", "C", "AB", "AC", "BC", "A²", "B²", "C²"]
def X_of(a, b, c):
    a, b, c = map(np.asarray, (a, b, c))
    return np.column_stack([np.ones_like(a, dtype=float), a, b, c, a * b, a * c, b * c, a ** 2, b ** 2, c ** 2])
X = X_of(A, B, C)
RESP = {"vth": "Vt (V)", "log_leakage": "log10(漏电流)", "yield": "良率"}
fits, coef_tables = {}, {}
for y in RESP:
    Y = design[y].values
    beta, *_ = np.linalg.lstsq(X, Y, rcond=None)
    res = Y - X @ beta; dof = len(Y) - X.shape[1]
    s2 = res @ res / dof
    se = np.sqrt(np.diag(s2 * np.linalg.inv(X.T @ X)))
    t = beta / se; p = 2 * stats.t.sf(np.abs(t), dof)
    r2 = 1 - res @ res / ((Y - Y.mean()) @ (Y - Y.mean()))
    r2adj = 1 - (1 - r2) * (len(Y) - 1) / dof
    # 纯误差（中心点重复）与失拟检验
    cen = design[design.类型 == "中心点"][y]; pe_ss = ((cen - cen.mean()) ** 2).sum(); pe_df = len(cen) - 1
    lof_ss = res @ res - pe_ss; lof_df = dof - pe_df
    F_lof = (lof_ss / lof_df) / (pe_ss / pe_df); p_lof = stats.f.sf(F_lof, lof_df, pe_df)
    fits[y] = dict(beta=beta, s=np.sqrt(s2), dof=dof, r2=r2, r2adj=r2adj, p_lof=p_lof, XtXi=np.linalg.inv(X.T @ X))
    tab = pd.DataFrame(dict(项=["截距"] + TERMS, 系数=beta, 标准误=se, t=t, p=p))
    coef_tables[y] = tab
    tab.to_csv(os.path.join(OUT, f"results/rsm_coef_{y}.csv"), index=False, float_format="%.4g")
def predict(y, a, b, c):
    return X_of(a, b, c) @ fits[y]["beta"]

# ---------- 5. 主效应与交互效应图 ----------
fig, axes = plt.subplots(3, 3, figsize=(11, 8.4), sharey="row")
for i, y in enumerate(RESP):
    for j, k in enumerate("ABC"):
        ax = axes[i, j]
        m = design.groupby(k)[y].mean()
        ax.plot([to_real(k, v) for v in m.index], m.values, "o-", color="#1f6feb", lw=2)
        ax.axhline(design[y].mean(), color="gray", ls="--", lw=0.8)
        if i == 2: ax.set_xlabel(f"{FACTORS[k]['name']}（{FACTORS[k]['unit']}）")
        if j == 0: ax.set_ylabel(RESP[y])
        if i == 0: ax.set_title(f"因子 {k}：{FACTORS[k]['name']}")
fig.suptitle("主效应图（每点为该水平下所有晶圆的平均响应，虚线为总平均）", fontsize=12)
fig.tight_layout(); fig.savefig(os.path.join(OUT, "figures/fig1_main_effects.png")); plt.close(fig)

fig, axes = plt.subplots(2, 3, figsize=(11, 6.4))
cs = design[design.类型 == "角点"]
for i, y in enumerate(["vth", "log_leakage"]):
    for j, (k1, k2) in enumerate([("A", "B"), ("A", "C"), ("B", "C")]):
        ax = axes[i, j]
        for lv, col, ls in [(-1, "#1f6feb", "-"), (1, "#cf222e", "--")]:
            m = cs[cs[k2] == lv].groupby(k1)[y].mean()
            ax.plot([to_real(k1, v) for v in m.index], m.values, "o" + ls, color=col,
                    label=f"{FACTORS[k2]['name']} = {to_real(k2, lv):.3g}")
        ax.set_title(f"{k1} × {k2} 交互", fontsize=11); ax.legend(fontsize=7)
        if i == 1: ax.set_xlabel(f"{FACTORS[k1]['name']}（{FACTORS[k1]['unit']}）")
        if j == 0: ax.set_ylabel(RESP[y])
fig.suptitle("交互效应图（角点数据；两条线不平行说明存在交互作用）", fontsize=12)
fig.tight_layout(); fig.savefig(os.path.join(OUT, "figures/fig2_interactions.png")); plt.close(fig)

fig, axes = plt.subplots(1, 3, figsize=(12, 4))
for ax, y in zip(axes, RESP):
    tab = coef_tables[y].iloc[1:].copy(); tab["abs_t"] = tab.t.abs(); tab = tab.sort_values("abs_t")
    tcrit = stats.t.ppf(0.975, fits[y]["dof"])
    ax.barh(tab.项, tab.abs_t, color=["#cf222e" if v > tcrit else "#8c959f" for v in tab.abs_t])
    ax.axvline(tcrit, ls="--", color="black", lw=0.8); ax.text(tcrit, -0.9, " p = 0.05", fontsize=8)
    ax.set_title(RESP[y]); ax.set_xlabel("|t| 值")
fig.suptitle("效应 Pareto 图（红色为显著项）", fontsize=12)
fig.tight_layout(); fig.savefig(os.path.join(OUT, "figures/fig3_pareto.png")); plt.close(fig)

# ---------- 6. 规格与工艺窗口 ----------
SPEC = dict(vt_lo=0.52, vt_hi=0.65, logleak_hi=np.log10(1.0e-3), yield_lo=0.58)
ga = np.linspace(-1, 1, 81); gb = np.linspace(-1, 1, 81)
AA, BB = np.meshgrid(ga, gb)
fig, axes = plt.subplots(1, 3, figsize=(13.5, 4.4), sharey=True)
win_area = {}
for ax, cval in zip(axes, [-1, 0, 1]):
    a, b, c = AA.ravel(), BB.ravel(), np.full(AA.size, cval)
    vt = predict("vth", a, b, c).reshape(AA.shape)
    lk = predict("log_leakage", a, b, c).reshape(AA.shape)
    yd = predict("yield", a, b, c).reshape(AA.shape)
    ok = (vt >= SPEC["vt_lo"]) & (vt <= SPEC["vt_hi"]) & (lk <= SPEC["logleak_hi"]) & (yd >= SPEC["yield_lo"])
    win_area[cval] = ok.mean()
    xr, yr = to_real("A", AA), to_real("B", BB)
    cf = ax.contourf(xr, yr, yd, levels=np.linspace(0.40, 0.70, 13), cmap="Greens")
    ax.contourf(xr, yr, ok.astype(float), levels=[0.5, 1.5], colors="none", hatches=["//"])
    c1 = ax.contour(xr, yr, vt, levels=[SPEC["vt_lo"], SPEC["vt_hi"]], colors="#1f6feb", linewidths=1.6)
    ax.clabel(c1, fmt=lambda v: f"Vt={v:.2f}", fontsize=7)
    c2 = ax.contour(xr, yr, lk, levels=[SPEC["logleak_hi"]], colors="#cf222e", linewidths=1.6, linestyles="--")
    ax.clabel(c2, fmt=lambda v: "漏电上限", fontsize=7)
    ax.set_title(f"注入剂量 = {to_real('C', cval):.2e} cm⁻²", fontsize=11)
    ax.set_xlabel("栅长 CD（nm）")
axes[0].set_ylabel("栅介质厚度（Å）")
axes[1].plot(to_real("A", 0), to_real("B", 0), "s", ms=9, color="white", mec="black", label="当前条件（中心点）")
axes[1].legend(fontsize=8, loc="upper right")
WINDOW_AXES = axes
fig.colorbar(cf, ax=axes, shrink=0.85, label="预测良率")
fig.suptitle("工艺窗口等高线图：色阶为预测良率，斜线区域同时满足 Vt、漏电、良率三项规格", fontsize=12)
WINDOW_FIG = fig

# ---------- 7. 最优条件：窗口内、离边界最远（稳健优先） ----------
g = np.linspace(-1, 1, 41)
GA, GB, GC = [v.ravel() for v in np.meshgrid(g, g, g, indexing="ij")]
vt = predict("vth", GA, GB, GC); lk = predict("log_leakage", GA, GB, GC); yd = predict("yield", GA, GB, GC)
ok = (vt >= SPEC["vt_lo"]) & (vt <= SPEC["vt_hi"]) & (lk <= SPEC["logleak_hi"]) & (yd >= SPEC["yield_lo"])

# 工艺波动（取第二阶段 7nm 节点内标准差；剂量取 ±1% 机台重复性）
SIG = dict(A=1.08 / FACTORS["A"]["step"], B=2.0 / FACTORS["B"]["step"], C=0.01e15 / FACTORS["C"]["step"])
N_MC = 20000
def mc(a0, b0, c0):
    a = a0 + rng.normal(0, SIG["A"], N_MC); b = b0 + rng.normal(0, SIG["B"], N_MC); c = c0 + rng.normal(0, SIG["C"], N_MC)
    v = predict("vth", a, b, c) + rng.normal(0, fits["vth"]["s"], N_MC)
    l = predict("log_leakage", a, b, c) + rng.normal(0, fits["log_leakage"]["s"], N_MC)
    y = yield_model(v, l, a, b) + rng.normal(0, 0.025, N_MC)
    inspec = (v >= SPEC["vt_lo"]) & (v <= SPEC["vt_hi"]) & (l <= SPEC["logleak_hi"])
    return dict(inspec=inspec.mean(), yield_mean=y.mean(), vt_out=((v < SPEC["vt_lo"]) | (v > SPEC["vt_hi"])).mean(),
                leak_out=(l > SPEC["logleak_hi"]).mean(), vt_sd=v.std())

cand = np.where(ok)[0]
# 先按预测良率取前 5% 的候选，再选蒙特卡洛合格率最高者
top = cand[np.argsort(-yd[cand])][: max(30, len(cand) // 20)]
scores = []
for idx in top[::max(1, len(top) // 60)]:
    r = mc(GA[idx], GB[idx], GC[idx]); scores.append((idx, r["inspec"], r["yield_mean"]))
best_idx = max(scores, key=lambda s: (round(s[1], 3), s[2]))[0]
best = dict(A=GA[best_idx], B=GB[best_idx], C=GC[best_idx])
por = dict(A=0.0, B=0.0, C=0.0)
WINDOW_AXES[2].plot(to_real("A", best["A"]), to_real("B", best["B"]), "*", ms=16, color="gold", mec="black",
                    label=f"推荐条件（剂量 {to_real('C', best['C']):.3g}）")
WINDOW_AXES[2].legend(fontsize=8, loc="upper right")
WINDOW_FIG.savefig(os.path.join(OUT, "figures/fig4_process_window.png"), bbox_inches="tight"); plt.close(WINDOW_FIG)
res_best, res_por = mc(**{k.lower() + "0": v for k, v in best.items()}), mc(a0=0, b0=0, c0=0)

def pred_interval(y, a, b, c):
    x = X_of([a], [b], [c])[0]; f = fits[y]
    se = f["s"] * np.sqrt(1 + x @ f["XtXi"] @ x); tq = stats.t.ppf(0.975, f["dof"])
    m = x @ f["beta"]; return float(m), float(m - tq * se), float(m + tq * se)

summary = dict(
    n_runs=len(design), spec=dict(vt=[SPEC["vt_lo"], SPEC["vt_hi"]], leak_max=1.0e-3, yield_min=SPEC["yield_lo"]),
    fit={y: dict(r2=round(f["r2"], 3), r2adj=round(f["r2adj"], 3), s=round(float(f["s"]), 4), p_lack_of_fit=round(float(f["p_lof"]), 3)) for y, f in fits.items()},
    significant={y: coef_tables[y].query("p < 0.05 and 项 != '截距'").项.tolist() for y in RESP},
    window_fraction_by_dose={f"{to_real('C', c):.2e}": round(float(v), 3) for c, v in win_area.items()},
    best_coded={k: round(float(v), 2) for k, v in best.items()},
    best_real={FACTORS[k]["name"]: round(float(to_real(k, v)), 3 if k != "C" else -11) for k, v in best.items()},
    best_pred={y: [round(v, 4) for v in pred_interval(y, best["A"], best["B"], best["C"])] for y in RESP},
    por_pred={y: [round(v, 4) for v in pred_interval(y, 0, 0, 0)] for y in RESP},
    mc_best={k: round(float(v), 4) for k, v in res_best.items()},
    mc_por={k: round(float(v), 4) for k, v in res_por.items()},
    sigma_used=dict(CD="1.08 nm", oxide="2.0 Å", dose="1%"),
)
# 窗口边界：在最优点处，单因子允许变化范围（其余两因子固定）
bounds = {}
for k in "ABC":
    xs = np.linspace(-1.5, 1.5, 301); pts = {kk: np.full_like(xs, best[kk]) for kk in "ABC"}; pts[k] = xs
    v = predict("vth", pts["A"], pts["B"], pts["C"]); l = predict("log_leakage", pts["A"], pts["B"], pts["C"])
    y_ = predict("yield", pts["A"], pts["B"], pts["C"])
    okk = (v >= SPEC["vt_lo"]) & (v <= SPEC["vt_hi"]) & (l <= SPEC["logleak_hi"]) & (y_ >= SPEC["yield_lo"])
    # 取包含最优点的连续区间
    i0 = np.argmin(np.abs(xs - best[k])); lo = hi = i0
    while lo > 0 and okk[lo - 1]: lo -= 1
    while hi < len(xs) - 1 and okk[hi + 1]: hi += 1
    lo_lim = "超出实验范围" if lo == 0 else round(float(to_real(k, xs[lo])), 3 if k != "C" else -11)
    hi_lim = "超出实验范围" if hi == len(xs) - 1 else round(float(to_real(k, xs[hi])), 3 if k != "C" else -11)
    bounds[FACTORS[k]["name"]] = [lo_lim, hi_lim]
summary["single_factor_window_at_best"] = bounds
with open(os.path.join(OUT, "results/summary.json"), "w", encoding="utf-8") as f:
    json.dump(summary, f, ensure_ascii=False, indent=2, default=float)

# 蒙特卡洛分布图
fig, axes = plt.subplots(1, 2, figsize=(11, 3.8))
for ax, (lab, pt, col) in zip([axes[0]] * 2, [("当前条件（中心点）", por, "#8c959f"), ("推荐条件", best, "#2da44e")]):
    a = pt["A"] + rng.normal(0, SIG["A"], N_MC); b = pt["B"] + rng.normal(0, SIG["B"], N_MC); c = pt["C"] + rng.normal(0, SIG["C"], N_MC)
    v = predict("vth", a, b, c) + rng.normal(0, fits["vth"]["s"], N_MC)
    l = predict("log_leakage", a, b, c) + rng.normal(0, fits["log_leakage"]["s"], N_MC)
    axes[0].hist(v, bins=60, alpha=0.55, color=col, label=lab, density=True)
    axes[1].hist(l, bins=60, alpha=0.55, color=col, label=lab, density=True)
for x in (SPEC["vt_lo"], SPEC["vt_hi"]): axes[0].axvline(x, color="#1f6feb", ls="--")
axes[1].axvline(SPEC["logleak_hi"], color="#cf222e", ls="--")
axes[0].set_xlabel("Vt (V)"); axes[1].set_xlabel("log10(漏电流)")
axes[0].set_title("Vt 分布（虚线为规格）"); axes[1].set_title("漏电流分布（虚线为上限）")
axes[0].legend(fontsize=8)
fig.suptitle("考虑正常工艺波动后的电性分布（蒙特卡洛 20000 次）", fontsize=12)
fig.tight_layout(); fig.savefig(os.path.join(OUT, "figures/fig5_monte_carlo.png")); plt.close(fig)

print(json.dumps(summary, ensure_ascii=False, indent=2, default=float))
for y in RESP:
    print(y); print(coef_tables[y].round(4).to_string(index=False))
