"""
第四阶段：良率提升路径推演
基于第二阶段（历史数据回归）与第三阶段（DOE 响应面模型）的结果，
以 7nm 产品为对象，估算各项改善措施的良率收益，并画出瀑布图。

运行：python stage4_yield_path.py path/to/semiconductor_yield_forecasting_data.csv
依赖：numpy, pandas, scipy, scikit-learn, matplotlib；需与 stage3/stage3_doe.py 同级目录结构
"""
import sys, os, json, importlib.util
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.linear_model import LinearRegression
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams["font.sans-serif"] = ["Noto Sans CJK SC", "PingFang SC", "Microsoft YaHei", "SimHei"]
plt.rcParams["axes.unicode_minus"] = False
plt.rcParams["figure.dpi"] = 150

CSV = sys.argv[1] if len(sys.argv) > 1 else "semiconductor_yield_forecasting_data.csv"
OUT = os.path.dirname(os.path.abspath(__file__))
os.makedirs(os.path.join(OUT, "figures"), exist_ok=True); os.makedirs(os.path.join(OUT, "results"), exist_ok=True)
rng = np.random.default_rng(7)

d = pd.read_csv(CSV)
num = ["critical_dimension", "defect_density", "yield"]
cen = d[num] - d.groupby("technology_node")[num].transform("mean")

# ---------- 1. 节点内回归：良率 ~ 缺陷密度 + CD（用于换算收益） ----------
X = cen[["defect_density", "critical_dimension"]].values
reg = LinearRegression().fit(X, cen["yield"].values)
b_dd, b_cd = reg.coef_
res = cen["yield"].values - reg.predict(X)
# 系数的置信区间（bootstrap，按批次重抽样以保留批次相关性）
lots = d.lot_id.unique(); boots = []
for _ in range(1000):
    pick = rng.choice(lots, len(lots), replace=True)
    idx = np.concatenate([np.where(d.lot_id.values == l)[0] for l in pick])
    boots.append(LinearRegression().fit(X[idx], cen["yield"].values[idx]).coef_[0])
b_dd_lo, b_dd_hi = np.percentile(boots, [2.5, 97.5])

s7 = d[d.technology_node == "7nm"].copy()
base = s7["yield"].mean()
dd_mean_7 = s7.defect_density.mean()

# ---------- 2. 措施一：消除设备漂移（缺陷密度回到漂移前水平） ----------
lot = d.assign(dd_c=cen.defect_density).groupby("lot_id").agg(date=("process_date", "first"), dd_c=("dd_c", "mean")).sort_values("date")
day = np.arange(len(lot)); slope = stats.linregress(day, lot.dd_c).slope
lot_day = dict(zip(lot.index, day))
s7["day"] = s7.lot_id.map(lot_day)
delta_drift = -slope * s7["day"]                  # 把每片的缺陷密度拉回第 0 天水平
gain_drift = b_dd * delta_drift.mean()          # b_dd < 0，delta < 0，收益为正
gain_drift_rng = sorted([b_dd_lo * delta_drift.mean(), b_dd_hi * delta_drift.mean()])

# ---------- 3. 措施二：颗粒缺陷控制（缺陷密度再降 10%，假设值） ----------
red = 0.10
delta_part = -red * (dd_mean_7 + delta_drift.mean())
gain_part = b_dd * delta_part
gain_part_rng = sorted([b_dd_lo * delta_part, b_dd_hi * delta_part])

# ---------- 4. 措施三、四：用第三阶段 DOE 模型（只取差值） ----------
spec = importlib.util.spec_from_file_location("doe", os.path.join(OUT, "..", "stage3", "stage3_doe.py"))
cwd = os.getcwd(); os.chdir(os.path.join(OUT, "..", "stage3"))
import contextlib, io
with contextlib.redirect_stdout(io.StringIO()):
    doe = importlib.util.module_from_spec(spec); spec.loader.exec_module(doe)
os.chdir(cwd)
def mc(a0, b0, c0, sigA_nm=1.08, n=40000, seed=11):
    r = np.random.default_rng(seed)
    a = a0 + r.normal(0, sigA_nm / 2.0, n); b = b0 + r.normal(0, 2.0 / 4.0, n); c = c0 + r.normal(0, 0.2, n)
    v = doe.predict("vth", a, b, c) + r.normal(0, doe.fits["vth"]["s"], n)
    l = doe.predict("log_leakage", a, b, c) + r.normal(0, doe.fits["log_leakage"]["s"], n)
    y = doe.yield_model(v, l, a, b)
    ins = (v >= 0.52) & (v <= 0.65) & (l <= np.log10(1e-3))
    return y.mean(), ins.mean(), ((v < 0.52) | (v > 0.65)).mean(), (l > -3).mean()
B = doe.best
y_por, in_por, vo_por, lo_por = mc(0, 0, 0)
y_cd, in_cd, vo_cd, lo_cd = mc(0, 0, 0, sigA_nm=0.80)
y_best, in_best, vo_best, lo_best = mc(B["A"], B["B"], B["C"], sigA_nm=0.80)
gain_cd = y_cd - y_por
gain_doe = y_best - y_cd
yse = doe.fits["yield"]["s"]

steps = [
    ("7nm 当前平均良率", base, None, None, "历史数据"),
    ("① 消除设备漂移", gain_drift, *gain_drift_rng, "高（第二阶段强证据）"),
    ("② 颗粒缺陷控制（再降 10%）", gain_part, *gain_part_rng, "中（降幅为假设）"),
    ("③ CD 管控收紧（σ 1.08→0.80 nm）", gain_cd, None, None, "中（DOE 模拟模型）"),
    ("④ 导入 DOE 推荐条件", gain_doe, None, None, "低（收益小于模型误差）"),
]
total = base + sum(s[1] for s in steps[1:])
summary = dict(
    base_7nm=round(base, 4), b_dd_per_unit=round(b_dd, 4), b_dd_ci=[round(b_dd_lo, 4), round(b_dd_hi, 4)],
    b_cd_per_unit=round(b_cd, 4), drift_slope_per_day=round(slope, 5),
    mean_drift_removed=round(float(-delta_drift.mean()), 4), dd_mean_7nm=round(dd_mean_7, 4),
    gains={s[0]: [round(s[1], 4), s[2] and round(s[2], 4), s[3] and round(s[3], 4), s[4]] for s in steps[1:]},
    target=round(total, 4),
    doe_mc=dict(por=dict(yield_=round(y_por, 4), inspec=round(in_por, 4), vt_out=round(vo_por, 4), leak_out=round(lo_por, 4)),
                cd_tight=dict(yield_=round(y_cd, 4), inspec=round(in_cd, 4), vt_out=round(vo_cd, 4), leak_out=round(lo_cd, 4)),
                best_cd_tight=dict(yield_=round(y_best, 4), inspec=round(in_best, 4), vt_out=round(vo_best, 4), leak_out=round(lo_best, 4))),
    doe_yield_model_s=round(yse, 4),
)
with open(os.path.join(OUT, "results/yield_path_summary.json"), "w", encoding="utf-8") as f:
    json.dump(summary, f, ensure_ascii=False, indent=2, default=float)

# ---------- 5. 瀑布图 ----------
fig, ax = plt.subplots(figsize=(10, 5))
cum = base; xs = range(len(steps) + 1)
ax.bar(0, base * 100, color="#8c959f")
ax.text(0, base * 100 + 0.4, f"{base*100:.1f}%", ha="center", fontsize=10)
colors = ["#2da44e", "#2da44e", "#57ab5a", "#a3d9a5"]
for i, (lab, g, lo, hi, conf) in enumerate(steps[1:], start=1):
    ax.bar(i, g * 100, bottom=cum * 100, color=colors[i - 1])
    if lo is not None:
        ax.errorbar(i, (cum + g) * 100, yerr=[[(g - lo) * 100], [(hi - g) * 100]], color="black", capsize=4, lw=1)
    ax.text(i, (cum + g) * 100 + 0.6, f"+{g*100:.1f}", ha="center", fontsize=10)
    cum += g
ax.bar(len(steps), total * 100, color="#1f6feb")
ax.text(len(steps), total * 100 + 0.4, f"{total*100:.1f}%", ha="center", fontsize=10, fontweight="bold")
ax.set_xticks(list(xs)); ax.set_xticklabels([s[0] for s in steps] + ["推演目标良率"], rotation=15, ha="right", fontsize=9)
ax.set_ylim(50, max(70, total * 100 + 3)); ax.set_ylabel("良率（%）")
ax.set_title("7nm 良率提升路径推演（误差线为 95% 置信区间；颜色越浅把握越低）")
fig.tight_layout(); fig.savefig(os.path.join(OUT, "figures/fig1_yield_waterfall.png")); plt.close(fig)

# 漂移消除前后的缺陷密度
fig, ax = plt.subplots(figsize=(9, 3.6))
ax.plot(pd.to_datetime(lot.date), lot.dd_c, "o-", ms=3, color="#cf222e", label="实际（随时间上升）")
ax.plot(pd.to_datetime(lot.date), lot.dd_c - slope * day, "o-", ms=3, color="#2da44e", label="消除漂移后（维持在初始水平）")
ax.axhline(0, color="gray", lw=0.6); ax.legend(fontsize=8)
ax.set_ylabel("缺陷密度（相对同节点均值）"); ax.set_title("措施①：通过缩短维护周期，使缺陷密度保持在漂移前的水平")
fig.autofmt_xdate(); fig.tight_layout(); fig.savefig(os.path.join(OUT, "figures/fig2_drift_removed.png")); plt.close(fig)
print(json.dumps(summary, ensure_ascii=False, indent=2, default=float))
